#define FIO_MAX_CPUS	MAXIMUM_PROCESSORS

typedef DWORD_PTR os_cpu_mask_t;
